--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8 (Debian 13.8-1.pgdg110+1)
-- Dumped by pg_dump version 13.8 (Debian 13.8-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE real_estate;
--
-- Name: real_estate; Type: DATABASE; Schema: -; Owner: zxc
--

CREATE DATABASE real_estate WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE real_estate OWNER TO zxc;

\connect real_estate

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: zxc
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO zxc;

--
-- Name: items; Type: TABLE; Schema: public; Owner: zxc
--

CREATE TABLE public.items (
    item_id integer NOT NULL,
    ad_id character varying,
    creator_id integer,
    title character varying,
    location character varying,
    address character varying,
    published_date timestamp without time zone,
    price integer,
    created_at timestamp without time zone,
    description character varying
);


ALTER TABLE public.items OWNER TO zxc;

--
-- Name: items_item_id_seq; Type: SEQUENCE; Schema: public; Owner: zxc
--

CREATE SEQUENCE public.items_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_item_id_seq OWNER TO zxc;

--
-- Name: items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zxc
--

ALTER SEQUENCE public.items_item_id_seq OWNED BY public.items.item_id;


--
-- Name: overview; Type: TABLE; Schema: public; Owner: zxc
--

CREATE TABLE public.overview (
    id integer NOT NULL,
    item_id integer,
    hydro boolean,
    heat boolean,
    water boolean,
    wifi boolean,
    parking smallint,
    agreement_type character varying,
    move_in_date character varying,
    pet_friendly character varying
);


ALTER TABLE public.overview OWNER TO zxc;

--
-- Name: overview_id_seq; Type: SEQUENCE; Schema: public; Owner: zxc
--

CREATE SEQUENCE public.overview_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.overview_id_seq OWNER TO zxc;

--
-- Name: overview_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zxc
--

ALTER SEQUENCE public.overview_id_seq OWNED BY public.overview.id;


--
-- Name: unit; Type: TABLE; Schema: public; Owner: zxc
--

CREATE TABLE public.unit (
    id integer NOT NULL,
    item_id integer,
    size smallint,
    furnished boolean,
    laundry_in_unit boolean,
    lundry_in_building boolean,
    dishwasher boolean,
    fridge boolean,
    air_conditioning boolean,
    balcony boolean,
    yard boolean,
    smoking_permitted boolean
);


ALTER TABLE public.unit OWNER TO zxc;

--
-- Name: unit_id_seq; Type: SEQUENCE; Schema: public; Owner: zxc
--

CREATE SEQUENCE public.unit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.unit_id_seq OWNER TO zxc;

--
-- Name: unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zxc
--

ALTER SEQUENCE public.unit_id_seq OWNED BY public.unit.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: zxc
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    name character varying,
    profile_url character varying,
    phone character varying,
    type character varying,
    listings smallint,
    website_url character varying,
    on_kijiji_from character varying,
    avg_reply character varying,
    reply_rate character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO zxc;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: zxc
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO zxc;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zxc
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: items item_id; Type: DEFAULT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.items ALTER COLUMN item_id SET DEFAULT nextval('public.items_item_id_seq'::regclass);


--
-- Name: overview id; Type: DEFAULT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.overview ALTER COLUMN id SET DEFAULT nextval('public.overview_id_seq'::regclass);


--
-- Name: unit id; Type: DEFAULT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.unit ALTER COLUMN id SET DEFAULT nextval('public.unit_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: zxc
--

COPY public.alembic_version (version_num) FROM stdin;
\.
COPY public.alembic_version (version_num) FROM '$$PATH$$/3029.dat';

--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: zxc
--

COPY public.items (item_id, ad_id, creator_id, title, location, address, published_date, price, created_at, description) FROM stdin;
\.
COPY public.items (item_id, ad_id, creator_id, title, location, address, published_date, price, created_at, description) FROM '$$PATH$$/3033.dat';

--
-- Data for Name: overview; Type: TABLE DATA; Schema: public; Owner: zxc
--

COPY public.overview (id, item_id, hydro, heat, water, wifi, parking, agreement_type, move_in_date, pet_friendly) FROM stdin;
\.
COPY public.overview (id, item_id, hydro, heat, water, wifi, parking, agreement_type, move_in_date, pet_friendly) FROM '$$PATH$$/3035.dat';

--
-- Data for Name: unit; Type: TABLE DATA; Schema: public; Owner: zxc
--

COPY public.unit (id, item_id, size, furnished, laundry_in_unit, lundry_in_building, dishwasher, fridge, air_conditioning, balcony, yard, smoking_permitted) FROM stdin;
\.
COPY public.unit (id, item_id, size, furnished, laundry_in_unit, lundry_in_building, dishwasher, fridge, air_conditioning, balcony, yard, smoking_permitted) FROM '$$PATH$$/3037.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: zxc
--

COPY public.users (user_id, name, profile_url, phone, type, listings, website_url, on_kijiji_from, avg_reply, reply_rate, created_at) FROM stdin;
\.
COPY public.users (user_id, name, profile_url, phone, type, listings, website_url, on_kijiji_from, avg_reply, reply_rate, created_at) FROM '$$PATH$$/3031.dat';

--
-- Name: items_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zxc
--

SELECT pg_catalog.setval('public.items_item_id_seq', 870, true);


--
-- Name: overview_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zxc
--

SELECT pg_catalog.setval('public.overview_id_seq', 870, true);


--
-- Name: unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zxc
--

SELECT pg_catalog.setval('public.unit_id_seq', 870, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zxc
--

SELECT pg_catalog.setval('public.users_user_id_seq', 765, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (item_id);


--
-- Name: overview overview_pkey; Type: CONSTRAINT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.overview
    ADD CONSTRAINT overview_pkey PRIMARY KEY (id);


--
-- Name: unit unit_pkey; Type: CONSTRAINT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.unit
    ADD CONSTRAINT unit_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: ix_items_item_id; Type: INDEX; Schema: public; Owner: zxc
--

CREATE INDEX ix_items_item_id ON public.items USING btree (item_id);


--
-- Name: ix_overview_id; Type: INDEX; Schema: public; Owner: zxc
--

CREATE INDEX ix_overview_id ON public.overview USING btree (id);


--
-- Name: ix_unit_id; Type: INDEX; Schema: public; Owner: zxc
--

CREATE INDEX ix_unit_id ON public.unit USING btree (id);


--
-- Name: ix_users_user_id; Type: INDEX; Schema: public; Owner: zxc
--

CREATE INDEX ix_users_user_id ON public.users USING btree (user_id);


--
-- Name: items items_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(user_id);


--
-- Name: overview overview_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.overview
    ADD CONSTRAINT overview_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(item_id);


--
-- Name: unit unit_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.unit
    ADD CONSTRAINT unit_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(item_id);


--
-- PostgreSQL database dump complete
--

